using CalculadoraCientifica;

namespace CalculadoraCientificaTests
{
    [TestClass]
    public class Calculadora4OperacoesTests
    {
        [TestMethod]
        public void Test_soma_dois_numeros()
        {
            //cenario
            int num1 = 20;
            int num2 = 22;
            int resultadoEsperado = 42;
            Calculadora4Operacoes calc = new Calculadora4Operacoes(); 

            //a��o
            int resultadoObtido = calc.Somar(num1,num2);

            //verifica��o
            Assert.AreEqual(resultadoObtido, resultadoEsperado, 0, "falha na realiza��o da soma");
        }

        [TestMethod]
        public void Test_mult_dois_numeros()
        {
            int num3 = 10;
            int num4 = 6;
            int resultadoEsperado = 60;
            Calculadora4Operacoes multi = new Calculadora4Operacoes();

            int resultadoObtido = multi.Mult(num3, num4);

            Assert.AreEqual(resultadoObtido, resultadoEsperado, 0, "falha na realiza��o da multiplica��o");
        }
    }
}