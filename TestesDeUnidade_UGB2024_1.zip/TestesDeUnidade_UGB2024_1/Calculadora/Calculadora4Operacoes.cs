﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraCientifica
{
    public class Calculadora4Operacoes
    {
        public int Somar(int num1, int num2)
        { 
            return num1 + num2;
        }
        
        public int Mult(int num3, int num4)
        {
            return (num3 * num4);
        }
    }
}
